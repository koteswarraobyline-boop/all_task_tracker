/** PM2 process config — run from server/: pm2 start ecosystem.config.cjs */
module.exports = {
  apps: [
    {
      name: 'task-tracker-api',
      script: './server.js',
      cwd: __dirname,
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      watch: false,
      max_memory_restart: '512M',
      env: {
        NODE_ENV: 'production',
      },
      wait_ready: true,
      listen_timeout: 30000,
      kill_timeout: 10000,
      merge_logs: true,
      time: true,
    },
  ],
};
