const jwt = require('jsonwebtoken');

const isProd = process.env.NODE_ENV === 'production';
const DEV_FALLBACK = 'dev-task-tracker-secret-change-me';
const JWT_SECRET = process.env.JWT_SECRET || (isProd ? null : DEV_FALLBACK);

if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET is required when NODE_ENV=production. Set it in server/.env');
  process.exit(1);
}

if (isProd && (JWT_SECRET.includes('change') || JWT_SECRET.includes('dev-task-tracker'))) {
  console.error('FATAL: JWT_SECRET must not use a development default in production.');
  process.exit(1);
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const token = header.slice(7);
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.admin = { id: payload.id, username: payload.username };
    return next();
  } catch {
    return res.status(401).json({ error: 'Unauthorized' });
  }
}

module.exports = {
  authMiddleware,
  JWT_SECRET,
};
